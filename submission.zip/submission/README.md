# Submission Details
My submission contains the following:
- [x] Short report in PDF or DOC format according to the template provided
- [x] Video file of the screencast showing your presentation with commentary describing the process of creating and interacting with the visualisation
  - [Google Drive link](https://drive.google.com/drive/folders/1sP3HK-gHqvZ6jx_dlEvE-caYRJRl_bPQ?usp=share_link)
- [x] Source code, project or configuration files (as zip archive if necessary)
- [x] [GitHub repo link](https://github.com/sur-sakthy/data-visualisation-project)